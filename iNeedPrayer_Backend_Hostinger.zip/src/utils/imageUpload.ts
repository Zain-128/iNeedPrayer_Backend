import { randomBytes } from "crypto";
import { writeFile } from "fs/promises";
import path from "path";
import { isB2Configured, publicUrlForUpload, PUBLIC_BASE_URL, UPLOAD_ROOT } from "../contants.js";
import { uploadImageToB2 } from "./b2Storage.js";
import { compressImage } from "./imageCompress.js";
import { ensureUploadDir } from "./ensureUploadDir.js";

export type SavedImage = {
  url: string;
  absoluteUrl?: string;
  storage: "b2" | "local";
};

export async function saveUploadedImage(
  buffer: Buffer,
  kind: string
): Promise<SavedImage> {
  const { buffer: compressed, ext } = await compressImage(buffer, kind);
  const name = `${Date.now()}-${randomBytes(8).toString("hex")}.${ext}`;

  if (isB2Configured()) {
    const objectKey = `images/${kind}/${name}`;
    const url = await uploadImageToB2(objectKey, compressed, ext);
    return { url, storage: "b2" };
  }

  await ensureUploadDir();
  const absPath = path.join(UPLOAD_ROOT, name);
  await writeFile(absPath, compressed);
  const urlPath = `/uploads/${name}`;
  const urls = publicUrlForUpload(urlPath);
  // Prefer relative path in DB so clients can resolve against current API host.
  // absoluteUrl is still returned for clients that want a full URL immediately.
  return {
    url: urlPath,
    absoluteUrl: urls.absoluteUrl ?? (PUBLIC_BASE_URL ? `${PUBLIC_BASE_URL}${urlPath}` : undefined),
    storage: "local",
  };
}

export function pickUploadedFile(
  files: Record<string, Express.Multer.File[]> | undefined
): Express.Multer.File | undefined {
  return files?.image?.[0] ?? files?.file?.[0];
}
