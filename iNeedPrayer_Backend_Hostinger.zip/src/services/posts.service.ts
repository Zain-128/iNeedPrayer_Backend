import mongoose from "mongoose";
import { Post } from "../models/post.model.js";
import { PostReaction } from "../models/postReaction.model.js";
import { Comment } from "../models/comment.model.js";
import { CommentReaction } from "../models/commentReaction.model.js";
import { User } from "../models/user.model.js";
import { UserBlock } from "../models/userBlock.model.js";
import { GroupMember } from "../models/groupMember.model.js";
import { ChurchMember } from "../models/churchMember.model.js";
import { mapPost } from "../utils/mappers.js";
import { buildPostTranslations } from "./translate.service.js";
import { createNotification } from "./notifications.service.js";

async function excludedAuthorIds(
  viewerId?: string
): Promise<mongoose.Types.ObjectId[]> {
  const adminBlocked = await User.find({ status: "blocked" }).distinct("_id");
  if (!viewerId) return adminBlocked as mongoose.Types.ObjectId[];

  const me = new mongoose.Types.ObjectId(viewerId);
  const [iBlocked, blockedMe] = await Promise.all([
    UserBlock.find({ blocker: me }).distinct("blocked"),
    UserBlock.find({ blocked: me }).distinct("blocker"),
  ]);
  return [...iBlocked, ...blockedMe, ...adminBlocked] as mongoose.Types.ObjectId[];
}

function assertPostVisible(post: { moderationStatus?: string }) {
  if (post.moderationStatus === "Hidden") {
    throw httpError("Post not found", 404);
  }
}

async function reactionFlags(userId: string | undefined, postIds: string[]) {
  if (!userId || !postIds.length) {
    return new Map<string, { pray: boolean; praise: boolean; like: boolean }>();
  }
  const uid = new mongoose.Types.ObjectId(userId);
  const rows = await PostReaction.find({
    user: uid,
    post: { $in: postIds.map((id) => new mongoose.Types.ObjectId(id)) },
  }).lean();
  const m = new Map<string, { pray: boolean; praise: boolean; like: boolean }>();
  for (const id of postIds) {
    m.set(id, { pray: false, praise: false, like: false });
  }
  for (const r of rows) {
    const pid = String(r.post);
    const cur = m.get(pid) ?? { pray: false, praise: false, like: false };
    if (r.type === "pray") cur.pray = true;
    if (r.type === "praise") cur.praise = true;
    if (r.type === "like") cur.like = true;
    m.set(pid, cur);
  }
  return m;
}

function httpError(message: string, statusCode: number) {
  const err = new Error(message);
  (err as Error & { statusCode?: number }).statusCode = statusCode;
  return err;
}

async function assertPostTarget(
  authorId: string,
  groupId?: string,
  churchId?: string
) {
  if (groupId && churchId) {
    throw httpError("Post cannot belong to both a group and a church", 400);
  }
  if (groupId) {
    const gm = await GroupMember.findOne({ group: groupId, user: authorId });
    if (!gm) throw httpError("Not a member of this group", 403);
  }
  if (churchId) {
    const cm = await ChurchMember.findOne({ church: churchId, user: authorId });
    if (!cm) throw httpError("Not a member of this church", 403);
  }
}

export async function listPosts(opts: {
  viewerId?: string;
  q?: string;
  page?: number;
  limit?: number;
  groupId?: string;
  authorId?: string;
  churchId?: string;
  lang?: string;
}) {
  const page = Math.max(1, opts.page ?? 1);
  const limit = Math.min(50, Math.max(1, opts.limit ?? 20));
  const skip = (page - 1) * limit;

  const exclude = await excludedAuthorIds(opts.viewerId);
  const conditions: Record<string, unknown>[] = [
    { moderationStatus: { $ne: "Hidden" } },
  ];

  if (opts.authorId) {
    if (exclude.some((id) => id.toString() === opts.authorId)) {
      return { posts: [], page, limit, total: 0 };
    }
    conditions.push({ author: new mongoose.Types.ObjectId(opts.authorId) });
  } else if (exclude.length) {
    conditions.push({ author: { $nin: exclude } });
  }

  if (opts.groupId) conditions.push({ group: opts.groupId });
  if (opts.churchId) conditions.push({ church: opts.churchId });

  if (opts.q?.trim()) {
    const rx = new RegExp(
      opts.q.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
      "i"
    );
    const users = await User.find({
      $or: [{ name: rx }, { email: rx }],
    })
      .select("_id")
      .lean();
    const userIds = users.map((u) => u._id);
    conditions.push({
      $or: [{ text: rx }, { author: { $in: userIds } }],
    });
  }

  const filter =
    conditions.length === 1
      ? conditions[0]
      : { $and: conditions };

  const [total, docs] = await Promise.all([
    Post.countDocuments(filter),
    Post.find(filter)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate("author", "name avatar city state country")
      .populate("group", "name image privacy")
      .populate("church", "name image")
      .lean(),
  ]);

  const ids = docs.map((d) => d._id.toString());
  const flags = await reactionFlags(opts.viewerId, ids);
  const posts = docs.map((p) => {
    const f = flags.get(p._id.toString()) ?? { pray: false, praise: false, like: false };
    return mapPost(p as never, {
      prayed: f.pray,
      praised: f.praise,
      liked: f.like,
      viewerId: opts.viewerId,
      lang: opts.lang,
    });
  });

  return { posts, page, limit, total };
}

export async function getPost(postId: string, viewerId?: string, lang?: string) {
  const exclude = await excludedAuthorIds(viewerId);
  const post = await Post.findById(postId)
    .populate("author", "name avatar city state country")
    .populate("group", "name image privacy")
    .populate("church", "name image")
    .lean();
  if (!post) {
    const err = new Error("Post not found");
    (err as Error & { statusCode?: number }).statusCode = 404;
    throw err;
  }
  assertPostVisible(post);
  if (
    exclude.some((id) => id.toString() === (post.author as { _id: mongoose.Types.ObjectId })._id.toString())
  ) {
    const err = new Error("Post not found");
    (err as Error & { statusCode?: number }).statusCode = 404;
    throw err;
  }
  const flags = await reactionFlags(viewerId, [postId]);
  const f = flags.get(postId) ?? { pray: false, praise: false, like: false };
  return mapPost(post as never, {
    prayed: f.pray,
    praised: f.praise,
    liked: f.like,
    viewerId,
    lang,
  });
}

export async function createPost(
  authorId: string,
  body: {
    text?: string;
    image?: string;
    mode?: "prayer" | "praise";
    groupId?: string;
    churchId?: string;
    sourceLanguage?: string;
  }
) {
  await assertPostTarget(authorId, body.groupId, body.churchId);

  const rawText = body.text?.trim() ?? "";
  const { sourceLanguage, translations } = await buildPostTranslations(
    rawText,
    body.sourceLanguage
  );

  const post = await Post.create({
    author: authorId,
    text: rawText,
    sourceLanguage,
    translations,
    image: body.image?.trim() ?? "",
    mode: body.mode === "praise" ? "praise" : "prayer",
    group: body.groupId || null,
    church: body.churchId || null,
  });
  await User.findByIdAndUpdate(authorId, { $inc: { postsCount: 1 } });

  const { recordAdminActivity } = await import(
    "./admin/adminActivity.service.js"
  );
  const mode = body.mode === "praise" ? "praise" : "prayer";
  void recordAdminActivity({
    type: mode === "praise" ? "praise_created" : "prayer_created",
    title:
      mode === "praise"
        ? "New praise created"
        : "New prayer request created",
    message: rawText.slice(0, 120) || "New post",
    refType: "post",
    refId: post._id.toString(),
    actorId: authorId,
    meta: { mode },
  });

  const populated = await Post.findById(post._id)
    .populate("author", "name avatar city state country")
    .populate("group", "name image privacy")
    .populate("church", "name image")
    .lean();
  const flags = await reactionFlags(authorId, [String(post._id)]);
  const f = flags.get(String(post._id)) ?? { pray: false, praise: false, like: false };
  return mapPost(populated as never, {
    prayed: f.pray,
    praised: f.praise,
    liked: f.like,
    viewerId: authorId,
  });
}

export async function updatePost(
  postId: string,
  authorId: string,
  body: {
    text?: string;
    image?: string;
    mode?: "prayer" | "praise";
    sourceLanguage?: string;
  }
) {
  const post = await Post.findById(postId);
  if (!post) throw httpError("Post not found", 404);
  if (post.author.toString() !== authorId) throw httpError("Not allowed", 403);

  if (body.text !== undefined) {
    const rawText = body.text.trim();
    const { sourceLanguage, translations } = await buildPostTranslations(
      rawText,
      body.sourceLanguage ?? post.sourceLanguage
    );
    post.text = rawText;
    post.sourceLanguage = sourceLanguage;
    post.translations = translations as never;
  }
  if (body.image !== undefined) post.image = body.image.trim();
  if (body.mode !== undefined)
    post.mode = body.mode === "praise" ? "praise" : "prayer";
  await post.save();
  const populated = await Post.findById(post._id)
    .populate("author", "name avatar city state country")
    .populate("group", "name image privacy")
    .populate("church", "name image")
    .lean();
  const flags = await reactionFlags(authorId, [postId]);
  const f = flags.get(postId) ?? { pray: false, praise: false, like: false };
  return mapPost(populated as never, {
    prayed: f.pray,
    praised: f.praise,
    liked: f.like,
    viewerId: authorId,
  });
}

export async function deletePost(postId: string, authorId: string) {
  const post = await Post.findById(postId);
  if (!post) {
    const err = new Error("Post not found");
    (err as Error & { statusCode?: number }).statusCode = 404;
    throw err;
  }
  if (post.author.toString() !== authorId) {
    const err = new Error("Not allowed");
    (err as Error & { statusCode?: number }).statusCode = 403;
    throw err;
  }
  const commentIds = await Comment.find({ post: postId }).distinct("_id");
  await Promise.all([
    PostReaction.deleteMany({ post: postId }),
    CommentReaction.deleteMany({ comment: { $in: commentIds } }),
    Comment.deleteMany({ post: postId }),
    post.deleteOne(),
    User.findByIdAndUpdate(authorId, { $inc: { postsCount: -1 } }),
  ]);
}

export async function togglePray(postId: string, userId: string) {
  const post = await Post.findById(postId);
  if (!post) {
    const err = new Error("Post not found");
    (err as Error & { statusCode?: number }).statusCode = 404;
    throw err;
  }
  assertPostVisible(post);
  const existing = await PostReaction.findOne({
    post: postId,
    user: userId,
    type: "pray",
  });
  if (existing) {
    await existing.deleteOne();
    post.praysCount = Math.max(0, post.praysCount - 1);
    await post.save();
    return { active: false, praysCount: post.praysCount };
  }
  await PostReaction.create({ post: postId, user: userId, type: "pray" });
  post.praysCount += 1;
  await post.save();
  const actor = await User.findById(userId).select("name").lean();
  await createNotification({
    userId: post.author.toString(),
    actorId: userId,
    title: "New prayer",
    body: `${actor?.name?.trim() || "Someone"} prayed for your post`,
    kind: "pray",
    refType: "post",
    refId: postId,
    category: "prayersAndPraises",
  });
  return { active: true, praysCount: post.praysCount };
}

export async function togglePraise(postId: string, userId: string) {
  const post = await Post.findById(postId);
  if (!post) {
    const err = new Error("Post not found");
    (err as Error & { statusCode?: number }).statusCode = 404;
    throw err;
  }
  assertPostVisible(post);
  const existing = await PostReaction.findOne({
    post: postId,
    user: userId,
    type: "praise",
  });
  if (existing) {
    await existing.deleteOne();
    post.praisesCount = Math.max(0, post.praisesCount - 1);
    await post.save();
    return { active: false, praisesCount: post.praisesCount };
  }
  await PostReaction.create({ post: postId, user: userId, type: "praise" });
  post.praisesCount += 1;
  await post.save();
  const actor = await User.findById(userId).select("name").lean();
  await createNotification({
    userId: post.author.toString(),
    actorId: userId,
    title: "New praise",
    body: `${actor?.name?.trim() || "Someone"} praised your post`,
    kind: "praise",
    refType: "post",
    refId: postId,
    category: "prayersAndPraises",
  });
  return { active: true, praisesCount: post.praisesCount };
}

export async function toggleLike(postId: string, userId: string) {
  const post = await Post.findById(postId);
  if (!post) throw httpError("Post not found", 404);
  assertPostVisible(post);
  const existing = await PostReaction.findOne({
    post: postId,
    user: userId,
    type: "like",
  });
  if (existing) {
    await existing.deleteOne();
    post.likesCount = Math.max(0, post.likesCount - 1);
    await post.save();
    return { liked: false, likesCount: post.likesCount };
  }
  await PostReaction.create({ post: postId, user: userId, type: "like" });
  post.likesCount += 1;
  await post.save();
  const actor = await User.findById(userId).select("name").lean();
  await createNotification({
    userId: post.author.toString(),
    actorId: userId,
    title: "New like",
    body: `${actor?.name?.trim() || "Someone"} liked your post`,
    kind: "like",
    refType: "post",
    refId: postId,
    category: "postActivity",
  });
  return { liked: true, likesCount: post.likesCount };
}

export async function unlikePost(postId: string, userId: string) {
  const post = await Post.findById(postId);
  if (!post) throw httpError("Post not found", 404);
  assertPostVisible(post);
  const existing = await PostReaction.findOne({
    post: postId,
    user: userId,
    type: "like",
  });
  if (!existing) return { liked: false, likesCount: post.likesCount };
  await existing.deleteOne();
  post.likesCount = Math.max(0, post.likesCount - 1);
  await post.save();
  return { liked: false, likesCount: post.likesCount };
}

export async function incrementShare(postId: string) {
  const post = await Post.findById(postId);
  if (!post) {
    const err = new Error("Post not found");
    (err as Error & { statusCode?: number }).statusCode = 404;
    throw err;
  }
  assertPostVisible(post);
  post.sharesCount += 1;
  await post.save();
  return { sharesCount: post.sharesCount };
}

export async function listPrayPraiseUsers(
  postId: string,
  type: "pray" | "praise"
) {
  const rows = await PostReaction.find({ post: postId, type })
    .populate("user", "name avatar")
    .lean();
  return rows.map((r) => {
    const u = r.user as unknown as {
      _id: mongoose.Types.ObjectId;
      name: string;
      avatar?: string;
    };
    return {
      id: u._id.toString(),
      name: u.name,
      avatar: u.avatar ?? "",
      type,
    };
  });
}
