import mongoose from "mongoose";
import bcrypt from "bcrypt";

export interface IUser {
  email: string;
  password: string;
  name: string;
  avatar: string;
  coverImage: string;
  bio: string;
  preferredLanguage: string;
  city: string;
  state: string;
  country: string;
  followersCount: number;
  followingCount: number;
  postsCount: number;
  role: "user" | "admin";
  status: "active" | "inactive" | "blocked";
  blockedReason: string;
  blockedAt: Date | null;
  deletedAt: Date | null;
  socialLoginProvider?: string | null;
  socialLoginId?: string | null;
  createdAt: Date;
  updatedAt: Date;
  comparePassword(candidatePassword: string): Promise<boolean>;
}

const userSchema = new mongoose.Schema<IUser>(
  {
    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: {
      type: String,
      required: [true, "Password is required"],
      minlength: [6, "Password must be at least 6 characters"],
      select: false,
    },
    name: {
      type: String,
      required: [true, "Name is required"],
      trim: true,
    },
    avatar: { type: String, default: "" },
    coverImage: { type: String, default: "" },
    bio: { type: String, default: "", maxlength: 500 },
    preferredLanguage: { type: String, default: "en" },
    city: { type: String, default: "" },
    state: { type: String, default: "" },
    country: { type: String, default: "" },
    followersCount: { type: Number, default: 0 },
    followingCount: { type: Number, default: 0 },
    postsCount: { type: Number, default: 0 },
    role: {
      type: String,
      enum: ["user", "admin"],
      default: "user",
      index: true,
    },
    status: {
      type: String,
      enum: ["active", "inactive", "blocked"],
      default: "active",
      index: true,
    },
    blockedReason: { type: String, default: "" },
    blockedAt: { type: Date, default: null },
    deletedAt: { type: Date, default: null },
    socialLoginProvider: { type: String, default: null },
    socialLoginId: { type: String, default: null },
  },
  { timestamps: true }
);

userSchema.index(
  { socialLoginProvider: 1, socialLoginId: 1 },
  {
    unique: true,
    partialFilterExpression: {
      socialLoginId: { $exists: true, $type: "string", $ne: "" },
    },
  }
);

userSchema.index({ deletedAt: 1 });

userSchema.virtual("locationLabel").get(function () {
  const parts = [this.city, this.state, this.country].filter(Boolean);
  return parts.length ? parts.join(", ") : "";
});

userSchema.pre("save", async function () {
  if (!this.isModified("password")) return;
  this.password = await bcrypt.hash(this.password, 12);
});

userSchema.methods.comparePassword = async function (
  candidatePassword: string
): Promise<boolean> {
  return bcrypt.compare(candidatePassword, this.password);
};

export const User = mongoose.model<IUser>("User", userSchema);
